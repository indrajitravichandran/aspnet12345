﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LearnCentre
{
    public partial class Register : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            //Add your Code here for Requirement 5a
            if (Page.IsValid) {

                UserDetails user = new UserDetails();
                user.fname = Convert.ToString(fnametxt.Text);
                user.lname = Convert.ToString(lnametxt.Text);
                user.email = Convert.ToString(emailtxt.Text);
                user.cno = Convert.ToInt64(contacttxt.Text);
                user.eduQual = Convert.ToString(qualificationtxt.Text);
                user.intCourse = Convert.ToString(coursetxt.Text);
                user.add = Convert.ToString(addresstxt.Text);
                user.regDate = DateTime.Now;
                string connectionString = ConfigurationManager.ConnectionStrings["QuizDBConnectionString"].ConnectionString;
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = @"Select count(*) from StudentDetails where ContactNo='"+user.cno+"'";
                SqlCommand cmd = new SqlCommand(query, connection);
                int count = (int)cmd.ExecuteScalar();
                if (count > 0)
                {
                    ErrorMessage.Text = "Record Already exists";
                }

                else {
                    Session.Add("userDetails", user);

                    //Redirect to Test.aspx Web page
                    Response.RedirectToRoute("TestPageRoute");
                }//Insert the code here to initialize the members of UserDetails class as per the details entered by the user.
                

            }
               
            }
    }
}