﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LearnCentre
{
    public partial class Result : System.Web.UI.Page
    {
        int cnt = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userDetails"] == null)
            {
                Response.RedirectToRoute("RegisterationPageRoute");
            }
            ArrayList al = (ArrayList)Session["AnswerList"];

            foreach (Answer k in al)
            {
                if (k.Result == "Correct")
                {

                    cnt++;
                }
            }

            UserDetails user = new UserDetails();
            user = (UserDetails)Session["userDetails"];
            user.score = cnt;
            user.enqStatus = "Pending";


            string connectionString = ConfigurationManager.ConnectionStrings["QuizDBConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = @"Insert into StudentDetails Values(@FName, @LName, @Email,@ContactNo, @Address, @EduQual,
                @IntCourse,@QuizID,@Score,@RegistrationDate,@EnquiryStatus)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(new SqlParameter("@FName",user.fname));
            cmd.Parameters.Add(new SqlParameter("@LName", user.lname));
            cmd.Parameters.Add(new SqlParameter("@Email", user.email));
            cmd.Parameters.Add(new SqlParameter("@ContactNo", user.cno));
            cmd.Parameters.Add(new SqlParameter("@Address", user.add));
            cmd.Parameters.Add(new SqlParameter("@EduQual", user.eduQual));
            cmd.Parameters.Add(new SqlParameter("@IntCourse", user.intCourse));
            cmd.Parameters.Add(new SqlParameter("@QuizID", user.quizID));
            cmd.Parameters.Add(new SqlParameter("@Score", user.score));
            cmd.Parameters.Add(new SqlParameter("@RegistrationDate", user.regDate));
            cmd.Parameters.Add(new SqlParameter("@EnquiryStatus", user.enqStatus));
            //Add your Code here for Requirement 5b
            int count = cmd.ExecuteNonQuery();
            if (count > 0)
            {
                Message.Text = String.Format("Thank you {0} {1}. Your details have been submitted successfully. Please wait for our call.", user.fname, user.lname);
                Session.Abandon();
            }
            else {
                Page.Title = "Oops!!";
                Message.Text = "Something strange happened. Please re-register using the registeration page.";
                Session.Abandon();
            }

            //If insertion process is successful

            //Message.Text = String.Format("Thank you {0} {1}. Your details have been submitted successfully. Please wait for our call.", user.fname, user.lname);
            //Session.Abandon();

            //If insertion process fails
            //

        }
    }
}