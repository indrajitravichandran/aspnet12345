﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

namespace LearnCentre
{
    public partial class Register : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            //Add your Code here for Requirement 5a
            int i = 0;
            string conString = ConfigurationManager.ConnectionStrings["QuizDBConnectionString"].ToString();
            string queryString  = @"Select count(*) from StudentDetails where ContactNo = '" + TextBox4.Text + "'";
            UserDetails user = new UserDetails();
            //Insert the code here to initialize the members of UserDetails class as per the details entered by the user.
            user.fname = TextBox1.Text;
            user.lname = TextBox2.Text;
            user.email = TextBox3.Text;
            user.cno = Convert.ToInt64(TextBox4.Text);
            user.add = TextBox5.Text;
            user.eduQual = TextBox6.Text;
            user.intCourse = TextBox7.Text;
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(queryString, con))
                {
                    con.Open();
                    i = (int)cmd.ExecuteScalar();
                    con.Close();
                }
            }
            if (i == 0)
            {
                Session.Add("userDetails", user);
                Response.RedirectToRoute("TestPageRoute");
            }
            else
            {
                ErrorMessage.Text = "This user already exists.";
                ErrorMessage.Visible = true;
            }
         }
    }
}