﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LearnCentre
{
    public class UserDetails
    {
        public string fname { get; set; }
        public string lname { get; set; }
        public string email { get; set; }
        public long cno { get; set; }
        public string add { get; set; }
        public string eduQual { get; set; }
        public string intCourse { get; set; }
        public int quizID { get; set; }
        public int score { get; set; }
        public DateTime regDate { get; set; }
        public string enqStatus { get; set; }
    }
}