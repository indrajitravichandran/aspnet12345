﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LearnCentre
{
    public partial class Result : System.Web.UI.Page
    {
        int cnt = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userDetails"] == null)
            {
                Response.RedirectToRoute("RegisterationPageRoute");
            }
            ArrayList al = (ArrayList)Session["AnswerList"];

            foreach (Answer k in al)
            {
                if (k.Result == "Correct")
                {

                    cnt++;
                }
            }

            UserDetails user = new UserDetails();
            user = (UserDetails)Session["userDetails"];
            user.score = cnt;
            user.enqStatus = "Pending";
            user.regDate = DateTime.Now;
            int i = 0;
            string conString = ConfigurationManager.ConnectionStrings["QuizDBConnectionString"].ToString();
            string queryString = @"insert into StudentDetails(FName,LName,Email,ContactNo,Address,EduQual,IntCourse,QuizID,Score,RegisterationDate,EnquiryStatus) values ('" + user.fname + "','" + user.lname + "','" + user.email + "','" + user.cno + "','" + user.add + "','" + user.eduQual + "','" + user.intCourse + "','" + user.quizID + "','" + user.score + "','" + user.regDate + "','" + user.enqStatus + "')";
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand(queryString, con))
                {
                    con.Open();
                    i = cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            //Add your Code here for Requirement 5b
            if (i > 0)
            {
                Message.Text = String.Format("Thank you {0} {1}. Your details have been submitted successfully. Please wait for our call.", user.fname, user.lname);
                Session.Abandon();
            }
            else
            {
                Page.Title = "Oops!!";
                Message.Text = "Something strange happened. Please re-register using the registeration page.";
                Session.Abandon();
            }
            
        }
    }
}